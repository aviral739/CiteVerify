---
name: CiteVerify
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464553'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777584'
  outline-variant: '#c8c4d5'
  surface-tint: '#544fc0'
  primary: '#1f108e'
  on-primary: '#ffffff'
  primary-container: '#3730a3'
  on-primary-container: '#a9a7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#4e1f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#703000'
  on-tertiary-container: '#ff9454'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3b35a7'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68e'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#763300'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 3.5rem
    fontWeight: '400'
    lineHeight: 4rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 2.25rem
    fontWeight: '400'
    lineHeight: 2.75rem
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 2.25rem
    fontWeight: '500'
    lineHeight: 2.75rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 1.75rem
    fontWeight: '500'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
  headline-sm:
    fontFamily: Newsreader
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.875rem
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.04em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.375rem
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an exacting, high-integrity editorial environment built specifically for scholarly rigor, citation lineage auditing, and automated claim verification. The UI evokes the quiet authority of premier academic journals married to the precision of modern analytical tooling.

The aesthetic philosophy is **Academic Editorial Minimalism**:
- Impartiality over ornamentation: Interfaces prioritize deep reading, complex verification trees, and micro-evidence diffing without visual distraction.
- Deliberate typographic tension: Grounded, literary serif display typography balances razor-sharp, systematic sans-serif operational metrics.
- Uncompromising crispness: 1px structural framing, subdued tonal contrast, and architectural white space create an environment of institutional trust and methodological reliability.

## Colors

The palette simulates high-grade archival paper illuminated by a disciplined editorial hierarchy:

- **Surface Base (`#FAFAFA`)**: An ultra-clean, desaturated off-white canvas that eliminates glare while maintaining crisp white container contrast.
- **Primary Ink (`#3730A3` / `#4338CA`)**: A deep scholar indigo used for authoritative interactive states, verified claim badges, and active document pivots.
- **Verification Secondary (`#0D9488`)**: A clinical teal-emerald designated strictly for peer-reviewed validations, verified DOI matching, and factual consensus confirmations.
- **Contested Tertiary (`#B45309`)**: A warm editorial amber signifying ambiguous claims, retractions under review, or unindexed citation warnings.
- **Neutral Core (`#0F172A`)**: Deep Slate-900 for typographic legibility, supported by structural border tones (`#E2E8F0` and `#CBD5E1`) for razor-thin data segregation.

## Typography

The typographic balance executes a strict structural division:
- **Newsreader** handles editorial narrative, research paper abstracts, verification headlines, and claim excerpts, providing classic academic authority.
- **Hanken Grotesk** serves as the primary engine for high-density UI text, comparison panels, reviewer commentary, and administrative controls.
- **JetBrains Mono** surfaces programmatic academic identifiers (DOIs, PMIDs, bibtex keys, confidence scores, and algorithmic diff markers).

Editorial longform excerpts should always be rendered with generous line heights (`1.875rem` on body-lg) to emulate classical publication readability.

## Layout & Spacing

The layout operates on a disciplined **12-column asymmetric grid** designed to accommodate split-pane workflows (e.g., source document alongside real-time citation analysis):

- **Desktop (1200px+)**: 12 columns with `1.5rem` gutters and `3rem` outer margins. Verification workspaces divide cleanly into an 8-column reading viewport and a 4-column claim metadata inspector.
- **Tablet (768px - 1199px)**: 8 columns with `1rem` gutters and `2rem` margins. The inspector collapses into a sliding analytical drawer.
- **Mobile (<768px)**: 4 columns with `1rem` gutters and `1.25rem` margins. Dense data panels stack vertically beneath extracted claims.

Spacing rhythm is strictly modular, governed by multiples of `0.25rem` (4px base), reserving larger clearances (`space-xl`) strictly between distinct manuscript sections.

## Elevation & Depth

This design system deliberately eschews standard diffuse drop shadows in favor of **Crisp Architectural Layering**:

- **Low-Contrast Outlines**: Elevation is communicated via subtle 1px borders (`#E2E8F0` for ambient containers, `#CBD5E1` for focused containers).
- **Surface Elevation**: Layering utilizes pure white (`#FFFFFF`) containers lifted above the off-white canvas (`#FAFAFA`). Secondary analytical cards use subtle neutral fills (`#F8FAFC`).
- **Focus & Floating Panels**: Modal overlays, context menus, and inline claim inspectors deploy an ultra-subtle directional shadow: `0 4px 12px -2px rgba(15, 23, 42, 0.06), 0 1px 2px 0 rgba(15, 23, 42, 0.04)`, bordered by a crisp `#CBD5E1` outline.

## Shapes

The design system enforces a **Soft Structural Geometry** (`roundedness: 1`):
- Default containers, cards, and input fields apply `0.25rem` (4px) corner radii.
- Secondary analytical panels, callouts, and multi-record table containers scale to `rounded-lg` (`0.5rem`).
- Strict non-pill geometry: Buttons, filters, and chips never exceed `0.25rem` to `0.375rem`, preserving a serious, print-inspired architectural posture reminiscent of archival catalog cards.

## Components

### Buttons
- **Primary**: Solid Indigo (`#3730A3`) fill, white text, 1px border (`#312E81`), 0.25rem radius. Interactive hover shifts to `#4338CA`.
- **Secondary / Citation Lookup**: Pure white background, Slate-900 text, 1px border in `#CBD5E1`. Hover: `#F8FAFC` surface with `#94A3B8` border.
- **Destructive / Flag Claim**: Transparent background, `#B91C1C` text, 1px border in `#FECACA`. Hover: `#FEF2F2` fill.

### Chips & Verification Tags
- **Confidence Badges**: Rendered using `label-sm` (JetBrains Mono).
  - *Verified*: Faint teal tint (`#F0FDFA`), `#0F766E` text, 1px border in `#CCFBF1`.
  - *Contested / Ambiguous*: Faint amber tint (`#FFFBEB`), `#92400E` text, 1px border in `#FDE68A`.
  - *Unindexed*: Faint slate tint (`#F1F5F9`), `#475569` text, 1px border in `#E2E8F0`.

### Cards & Claim Modules
- Pure white fill (`#FFFFFF`), enclosed in a 1px border (`#E2E8F0`).
- Padding strictly bounded to `space-md` or `space-lg`.
- Claim items display an editorial left accent: a 2px hairline border reflecting verification status (e.g., deep indigo for audited records, teal for verified citations).

### Input Fields & Search Bars
- Background: `#FFFFFF`, 1px border (`#CBD5E1`), 0.25rem radius.
- Active / Focus: Border transitions to `#3730A3` with a sharp `0 0 0 1px #3730A3` ring (no diffuse glow).
- Query prefixes and DOI filters use JetBrains Mono label tokens.

### Selection Controls (Checkboxes & Radios)
- 16px square (checkbox) or circle (radio), 1px border `#94A3B8`.
- Checked state: `#3730A3` fill with crisp white glyph centered.

### Specialized Component: Inline Claim Diff
- Compares original manuscript text against cited references. Rendered in a split or inline layout with subtle `#ECFDF5` (supported phrase) or `#FFF1F2` (divergent phrase) background bands, tagged with interactive citation footnotes linking directly to publisher DOIs.